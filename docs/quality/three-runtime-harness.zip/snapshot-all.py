from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET,collections
BASE=Path(__file__).resolve().parent;ROOT=Path(__import__('os').environ.get('ASSETSMODEL_ROOT','/home/ubuntu/workspace/chase/AssetsModel'));out=BASE/'assets';sha=lambda b:hashlib.sha256(b).hexdigest();refs={};urdfs=[]
for p in sorted((ROOT/'RobotModel').rglob('*.urdf')):
 data=p.read_bytes();name=p.relative_to(ROOT).as_posix();xml=ET.fromstring(data);urdfs.append({'path':name,'sha256':sha(data),'bytes':len(data)})
 for link in xml.findall('link'):
  for vi,visual in enumerate(link.findall('visual')):
   mesh=visual.find('geometry/mesh')
   if mesh is None:continue
   path=(p.parent/mesh.get('filename')).resolve()
   if path.suffix.lower()!='.glb':raise ValueError('nonGLB actual visual '+str(path))
   relative=path.relative_to(ROOT).as_posix();refs.setdefault(relative,[]).append({'urdf':name,'link':link.get('name'),'visual_index':vi})
reference=json.loads((ROOT/'docs/quality/runtime-visual-validation.json').read_text());same=set(refs)=={r['path'] for r in reference['glbs']};assert same, 'scope mismatch'
rows=[];modes=collections.Counter();attributes=collections.Counter()
import struct
for relative,owners in sorted(refs.items()):
 p=ROOT/relative;data=p.read_bytes();digest=sha(data);target=out/relative;target.parent.mkdir(parents=True,exist_ok=True)
 if not target.exists() or sha(target.read_bytes())!=digest:target.write_bytes(data)
 n=struct.unpack_from('<I',data,12)[0];tree=json.loads(data[20:20+n])
 for mesh in tree.get('meshes',[]):
  for prim in mesh['primitives']:modes[prim.get('mode',4)]+=1;attributes.update(prim['attributes'].keys())
 rows.append({'path':relative,'sha256':digest,'bytes':len(data),'urdf_references':owners})
manifest={'schema':'assetsmodel-three-all-visuals-v1','root':str(ROOT),'scope_reference':'docs/quality/runtime-visual-validation.json','scope_reference_sha256':sha((ROOT/'docs/quality/runtime-visual-validation.json').read_bytes()),'scope_match':same,'glbs':rows,'urdfs':urdfs,'primitive_modes':dict(modes),'attribute_semantics':dict(attributes),'input_manifest_sha256':sha(json.dumps({'glbs':rows,'urdfs':urdfs},sort_keys=True,separators=(',',':')).encode())};(BASE/'manifest-all.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(rows),'GLBs',len(urdfs),'URDFs',sum(r['bytes'] for r in rows),'bytes','modes',dict(modes),'attributes',dict(attributes))
