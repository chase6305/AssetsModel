AssetsModel real Three.js GLTFLoader acceptance fixture (session 2026-11-04)

This is an acceptance harness, not a website or shipped product flow. It never
writes RobotModel/CameraModel/ToolModel assets. Source snapshots, localhost HTML,
dependencies, caches and screenshots stay beside the harness. The repository
receives docs/quality/three-runtime-validation.json and
three-all-visuals-validation.json. Localhost URLs and /tmp files are not permanent
hosted artifacts.

Requirements: Node22, npm, Python3, Numpy for representative URDF FK reference,
and /usr/bin/google-chrome. playwright-core uses installed Chrome; it does not
download a browser. Official dependencies are pinned by package-lock.json:
three0.187.0 and playwright-core1.56.1, fetched once from the NPM registry.
After installation, browser execution loads only localhost files, with no CDN.

Extract this archive into an otherwise empty temporary directory, then:
  npm ci --ignore-scripts --no-audit --no-fund
  ASSETSMODEL_ROOT=/absolute/path/to/AssetsModel node run.mjs
  ASSETSMODEL_ROOT=/absolute/path/to/AssetsModel node run-all.mjs

run.mjs snapshots12 representative URDF/GLB closures, verifies P/N/UV/index bytes,
linear PBR and native material sidedness through actual GLTFLoader, assembles
originRzRyRx + axis/limits/mimic + visual scale, compares all link frames with an
independent Python/Numpy FK implementation, and captures hero/rear views.
RoomEnvironment/PMREM provides image-based lighting; native authored normals,
materials and front/back-face culling are retained. No prepare_preview geometry
is used. --only id,id can select a subset; --force bypasses valid image caches.

run-all.mjs independently resolves actual visual GLB references from RobotModel
URDFs and requires its set to match runtime-visual-validation.json. It verifies
all398 GLBs, every JSON primitive and every scene, including auxiliary CAD-guide
scenes, coincident reverse-wound surfaces and repeated instances. It does not
render398 models or claim additional whole-catalog FK. Resources are disposed per
file; explicit browser GC is attempted every10 files. --limit 5 is a smoke check;
--force bypasses matching inspection caches.

Cache keys include source file SHA, fixed dependency/fixture SHA and engine
identity (all-data stage). Endchecks compare current source SHA to the initial
input manifest. If assets change, rerun after the source is stable; affected keys
are invalidated. A prior manual review is reused only when its source fingerprint
and both rendered PNG hashes match exactly. Any changed source/image needs a new
human review. The included visual-review.json refers only to the original
reviewed session snapshot and images identified by hash.

Source code hashes and dependency integrity values are stored in reports. This
small archive contains harness code and locked dependency metadata, not Node
packages, robot assets or rendered screenshots. Reinstall dependencies once
before an offline browser run. Reported images are acceptance evidence, not
cross-engine pixel equivalence or measured manufacturer paint certification.

Official references:
https://threejs.org/docs/pages/GLTFLoader.html
https://threejs.org/docs/pages/RoomEnvironment.html
https://threejs.org/docs/pages/PMREMGenerator.html
https://threejs.org/manual/pages/color-management.html
