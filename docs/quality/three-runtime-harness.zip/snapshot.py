from pathlib import Path
import json,hashlib,shutil,sys,xml.etree.ElementTree as ET,math
import numpy as np
BASE=Path(__file__).resolve().parent;ROOT=Path(__import__('os').environ.get('ASSETSMODEL_ROOT','/home/ubuntu/workspace/chase/AssetsModel'));ASSETS=BASE/'assets'
new=json.loads((ROOT/'docs/quality/preview-new-models.json').read_text())['models'];old=json.loads((ROOT/'docs/quality/preview-models.json').read_text())['models']
models=[*new, next(x for x in old if x['id']=='fanuc-m10'),{'id':'fanuc-m710','label':'FANUC M-710iC/70','urdf':'RobotModel/Fanuc/M_710iC_70/M_710iC_70.urdf'},next(x for x in old if x['id']=='hans-e05'),{'id':'kuka-agilus2','label':'KUKA KR10 R900-2 standard white','urdf':'RobotModel/KUKA/KR10_R900_2/KR10_R900_2.urdf'},{'id':'kuka-kr210','label':'KUKA KR210 L150 orange','urdf':'RobotModel/KUKA/KR210_L150/KR210_L150.urdf'},{'id':'ur5','label':'Universal Robots UR5','urdf':'RobotModel/UniversalRobots/UR5/UR5.urdf'},next(x for x in old if x['id']=='franka-fr3'),{'id':'rokae-sr3','label':'ROKAE SR3','urdf':'RobotModel/Rokae/SR3/SR3.urdf'}]
sha=lambda b:hashlib.sha256(b).hexdigest()
def numbers(node,key,default):return [float(x) for x in (node.get(key,default) if node is not None else default).split()]
def origin(node):
 r,p,y=numbers(node,'rpy','0 0 0');cr,sr=math.cos(r),math.sin(r);cp,sp=math.cos(p),math.sin(p);cy,sy=math.cos(y),math.sin(y);M=np.eye(4);M[:3,:3]=[[cy*cp,cy*sp*sr-sy*cr,cy*sp*cr+sy*sr],[sy*cp,sy*sp*sr+cy*cr,sy*sp*cr-cy*sr],[-sp,cp*sr,cp*cr]];M[:3,3]=numbers(node,'xyz','0 0 0');return M
def joint_frames(xml,pose):
 links={x.get('name') for x in xml.findall('link')};joints={x.get('name'):x for x in xml.findall('joint')};values={};visiting=set()
 def value(name):
  if name in values:return values[name]
  if name in visiting:raise ValueError('mimic cycle')
  visiting.add(name);j=joints[name];m=j.find('mimic');q=value(m.get('joint'))*float(m.get('multiplier','1'))+float(m.get('offset','0')) if m is not None else float(pose.get(name,0));visiting.remove(name)
  if j.get('type') not in ('fixed','continuous'):
   l=j.find('limit')
   if l is not None and ('lower'in l.attrib or 'upper'in l.attrib) and not float(l.get('lower','-inf'))-1e-10<=q<=float(l.get('upper','inf'))+1e-10:raise ValueError('illegal joint '+name)
  values[name]=q;return q
 for name in joints:value(name)
 unknown=set(pose)-set(joints)
 if unknown:raise ValueError('unknown joints '+str(unknown))
 children={j.find('child').get('link') for j in joints.values()};frames={name:np.eye(4) for name in links-children};pending=list(joints.values())
 while pending:
  progress=False
  for j in pending[:]:
   parent=j.find('parent').get('link');child=j.find('child').get('link')
   if parent not in frames:continue
   move=np.eye(4);typ=j.get('type');q=values[j.get('name')];axis=np.array(numbers(j.find('axis'),'xyz','1 0 0'));n=np.linalg.norm(axis)
   if typ!='fixed':
    if not n:raise ValueError('zero axis')
    axis/=n
   if typ in ('revolute','continuous'):
    x,y,z=axis;K=np.array([[0,-z,y],[z,0,-x],[-y,x,0]]);move[:3,:3]=np.eye(3)*math.cos(q)+(1-math.cos(q))*np.outer(axis,axis)+math.sin(q)*K
   elif typ=='prismatic':move[:3,3]=axis*q
   elif typ!='fixed':raise ValueError('unsupported joint '+typ)
   frames[child]=frames[parent]@origin(j.find('origin'))@move;pending.remove(j);progress=True
  if not progress:raise ValueError('disconnected/cyclic joints')
 return {k:v.reshape(-1).tolist() for k,v in frames.items()},values
all_sources={}
for model in models:
 src=ROOT/model['urdf'];payload=src.read_bytes();xml=ET.fromstring(payload);source_rows=[]
 def copy(source):
  relative=source.relative_to(ROOT).as_posix();data=source.read_bytes();digest=sha(data);target=ASSETS/relative;target.parent.mkdir(parents=True,exist_ok=True)
  if not target.exists() or sha(target.read_bytes())!=digest:target.write_bytes(data)
  all_sources[relative]={'path':relative,'sha256':digest,'bytes':len(data)};return relative
 copy(src);visuals=[]
 for link in xml.findall('link'):
  for vi,visual in enumerate(link.findall('visual')):
   mesh=visual.find('geometry/mesh')
   if mesh is None:raise ValueError('fixture currently expects GLB visual, got '+link.get('name'))
   name=mesh.get('filename');path=(src.parent/name).resolve()
   if path.suffix.lower()!='.glb':raise ValueError('non-GLB '+str(path))
   rel=copy(path);visuals.append({'link':link.get('name'),'visual_index':vi,'source':rel,'sha256':all_sources[rel]['sha256'],'mesh_scale':numbers(mesh,'scale','1 1 1')})
 frames,values=joint_frames(xml,model.get('joints',{}));model.update(views=['hero','rear'],visuals=visuals,source_files=[all_sources[p] for p in sorted({model['urdf']}|{v['source'] for v in visuals})],expected_link_matrices_row_major=frames,resolved_joints=values)
 model['source_fingerprint']=sha(json.dumps(model['source_files'],sort_keys=True).encode())
manifest={'schema':'assetsmodel-three-runtime-v1','root':str(ROOT),'source_assets':str(ASSETS),'models':models,'all_sources':list(all_sources.values())}
(BASE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('snapshot',len(models),'models',len(all_sources),'files',sum(p['bytes'] for p in all_sources.values()),'bytes')
