# Franka Panda

This is the seven-axis Panda arm with the original two-finger Franka Hand,
imported from the official [franka_ros repository](https://github.com/frankarobotics/franka_ros/tree/ddd2fffd9de44b02ad15b4bbb2bfa2cec4d60d98/franka_description)
at commit `ddd2fffd9de44b02ad15b4bbb2bfa2cec4d60d98`.
It is the Panda description, not the newer Franka Research 3.
The upstream Apache-2.0 [LICENSE](LICENSE) and [NOTICE](NOTICE) are retained.

| Entry point | Assembly |
| --- | --- |
| `robot.urdf` | Panda arm and hand, with the original TCP frame |
| `arm.urdf` | Panda arm; root `panda_link0`, flange `panda_link8` |
| `hand.urdf` | Independent hand; root `panda_hand` |
| `home.json` | A reproducible legal arm configuration, fingers open by 0.02 m each |

All mesh paths are local to this directory. Joint names, axes, limits, damping,
origins, mimic relationship and collision geometries are retained. The auxiliary
`*_sc` links and their fixed joints remain present. This is the upstream Gazebo
geometry configuration: detailed environment STL collision meshes, primitive
finger collisions, and empty auxiliary self-collision frames. It does not enable
the inflated self-collision capsules used by the non-Gazebo source configuration.
Collision filtering and contact parameters remain simulator-specific.

## Physical data

**The inertia values are not official manufacturer measurements.** They are copied
unchanged from the upstream `robots/common/inertial.yaml`, which explicitly
attributes them to the identification results of Claudio Gaz, Marco Cognetti,
Alexander Oliva, Paolo Robuffo Giordano and Alessandro de Luca, *Identification of
the Franka Robotics Panda Robot With Retrieval of Feasible Parameters Using
Penalty-Based Optimization*. The original YAML and its warning are retained in
`source/robots/common/inertial.yaml`.

The source Xacro is expanded with `hand:=true gazebo:=true parent:=''` so that it
includes those inertia values without adding a world joint. Only Gazebo plugin,
transmission and other ROS runtime extension elements are omitted from the final
portable URDF. No inertial, kinematic or collision data is estimated by this import.
The arm-only entry uses `hand:=false` with the same remaining settings. The hand
entry is an exact subtree of the full robot.

## Visuals

Ten GLBs retain all **134,300 source surface triangles**, material regions and
authored split-normal directions. Trimesh normalizes the
already near-unit source normals; the source comparison records the resulting
float32 component differences. COLLADA scene transforms are baked
into mesh coordinates without an up-axis remapping; coordinates remain metres.
Six source CAD wire edges (two in link5, one in link6 and three in link7) are not
surface geometry and are omitted. Original DAE files are retained in
`source/meshes/` for comparison.

White covers, dark joint regions, the blue wrist details and colored buttons follow
the official Panda CAD material assignments. The two neutral-dark source diffuse
palettes, `[0.25, 0.25, 0.25, 1]` and
`[0.2509804, 0.2509804, 0.2509804, 1]`, are refined to linear PBR
`[0.035, 0.042, 0.055, 1]`. The original Panda photograph on page 31 of the
[October 2021 official manual](https://download.franka.de/Product-Manual-Franka-Emika-Robot_EN_10_2021.pdf)
shows distinctly dark grey joint covers, buttons and terminal fingertip pads.
Only their existing CAD material regions are remapped; white shells, light metal
finger bodies and colored details retain their source factors. These colors are
uncalibrated visual estimates, not measured manufacturer reflectance. The source
palette is not evidence of a gamma conversion error.

PBR metallic is explicitly zero;
roughness is 0.38 on the light covers and 0.48 on the dark regions. These are
authored rendering choices replacing the source's uniformly zero Phong shininess,
not measured brand color or surface constants. There are no URDF material
overrides, so standard GLB consumers use the same embedded finishes. Exact vertex
tuple compaction preserves all triangle-corner attributes and winding.

The nominal all-zero coordinate configuration lies outside the source limit on
`panda_joint4`; its upper limit is negative. The supplied preview therefore uses
the legal `home.json` configuration and resolves the second finger through its
original mimic joint. URDF joint zero frames and limits remain unchanged.
The main `preview.png` is rendered at 2400 × 2400 pixels and 256 Cycles samples;
the refined original-Panda finish has been visually reviewed.

## Reproduce

The importer requires Python, NumPy, trimesh, pycollada and xacro. It checks the
source revision and uses a temporary description copy, leaving the source
checkout untouched.

```bash
git clone https://github.com/frankarobotics/franka_ros.git /tmp/franka-source
git -C /tmp/franka-source checkout ddd2fffd9de44b02ad15b4bbb2bfa2cec4d60d98
python scripts/import_franka.py --source /tmp/franka-source
python scripts/refine_panda_palette.py  # verifies the integrated finish without writing
blender -b --factory-startup --python-exit-code 1 --python scripts/render_previews.py -- \
  FrankaPanda --joint-positions FrankaPanda/home.json --output-dir /tmp/franka-previews
```

`source-manifest.json` records source and generated SHA-256 hashes, face counts,
material counts and bounds. Mesh files and source descriptions remain under their
original Apache-2.0 license; the material conversion is an adapted version of
those assets.

## Validation

`validation.json` records zero errors or warnings for all three XML/URDF trees,
visual and collision loading in zero and articulated configurations, and Khronos
validation of the ten GLBs. The GLB validator reports three informational entries
for ten source degenerate triangles (five in link0, one in link4 and four in
link7). Those original faces are retained. All source float32 triangle-corner
positions compare exactly. Diffuse factors compare exactly before the separate
brand palette refinement, and all unselected palettes remain exact afterward.
Normal normalization changes
components by at most `2.384185791015625e-7`.

The source and portable descriptions also match in every link, joint, physical
field and collision mesh. Independent source-DAE/GLB loading at zero and home
gives identical link transforms and collision bounds; maximum visual world-bounds
difference is approximately `1.1e-9 m`. These are import and kinematic checks,
not dynamic contact validation or a standing/grasping controller.

The palette helper verifies complete source/result GLB hashes and source DAE
hashes, preserves every embedded binary buffer, and accepts an already refined
model without writing. The importer runs this same helper after its source
geometry/palette checks. Independent fresh imports reproduce the same mesh,
description, collision and manifest bytes. See
[`panda-dark-palette.json`](../docs/optimization-20261103/panda-dark-palette.json)
for individual material slots, hashes, guards and validation, and
[`panda-dark-palette.md`](../docs/optimization-20261103/panda-dark-palette.md)
for visual evidence.
