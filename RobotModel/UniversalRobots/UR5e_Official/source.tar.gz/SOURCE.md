# Universal Robots UR5e

Entry point: `robot.urdf` (six independent revolute joints, no end effector).
The visual assets use the official silver/grey, blue joint caps and black seals.

## Source and license

- Official description: [UniversalRobots/Universal_Robots_ROS2_Description](https://github.com/UniversalRobots/Universal_Robots_ROS2_Description).
- Fixed revision: [`3c173361e155231e5376d2682ddf920d3d79c112`](https://github.com/UniversalRobots/Universal_Robots_ROS2_Description/tree/3c173361e155231e5376d2682ddf920d3d79c112), `humble` branch as retrieved on 2026-11-03.
- Source inputs: `urdf/ur_macro.xacro`, its includes, `config/ur5e/`, and `meshes/ur5e/`.
- License: upstream BSD terms retained verbatim in [LICENSE](LICENSE).
- Appearance reference: [official UR5e product page](https://www.universal-robots.com/products/ur5-robot/). The mesh revision supplies the original per-face material assignments and diffuse colors.

`source/manifest.json` contains the pinned Git blob hashes for every import input.
`source/robot.urdf.orig` is the official macro expansion before portable paths.
The generated Xacro header comment uses a stable wrapper name instead of the
temporary directory; model elements and values are unaffected.
`source/config/` and `source/urdf/` retain the upstream description inputs. Original
DAE surfaces remain in `meshes/`; original STL collision meshes are in `collision/`.

## Conversion

The official macro is expanded with `ur_type=ur5e`, an empty joint prefix,
`parent=world`, and `generate_ros2_control_tag=false`. A temporary copy resolves
`$(find ur_description)` locally; no ROS installation is required to import or load
the flattened URDF. Link/joint names, axes, limits, transforms, mass, inertia,
collision shape/scale and the `flange`, `tool0`, `ft_frame` frames remain as authored.
The URDF differs from that expansion only in portable mesh paths; visual material
children, if present, are removed so embedded GLB materials supply the full palette.

COLLADA scene node transforms are baked into numeric mesh coordinates. Surface
polygons are triangulated with pycollada, preserving every source face. Twelve
non-surface CAD wire edges are omitted. Positions, triangle order/winding and
per-face material boundaries are checked after GLB serialization. The source
assigns flat face normals to many cylindrical CAD surfaces; these produce visible
faceting in standard renderers. A 35-degree, corner-angle-weighted pass smooths
only complete fans whose usable source normals were within 0.1 degree of their
face normals. Existing smooth fans, mechanical creases and material boundaries
are retained. All non-normal triangle-corner attributes remain exact; the
conversion report records the intentional normal changes. Zero source normals,
if encountered,
receive a geometric face normal, or a unit fallback on a zero-area face. The
conversion report records these cases. Source models and collision meshes are
retained exactly, including any source degeneracies.

The four named source materials retain their exact linear diffuse factors.
PBR values are visual approximations chosen here, not manufacturer measurements:

| Upstream material | Metallic | Roughness | Intended finish |
| --- | ---: | ---: | --- |
| `LinkGrey-material` | 0.70 | 0.30 | exposed silver link surfaces |
| `JointGrey-material` | 0.00 | 0.46 | grey coated joint housings |
| `URBlue-material` | 0.00 | 0.34 | blue joint covers |
| `Black-material` | 0.00 | 0.58 | black seals and fittings |

The default YAML is a nominal generic UR5e model. It is **not the individual
kinematic calibration of a physical arm**. The source joint limits and inertial
values are retained; this asset does not certify a controller or a task.

## Pose and regeneration

`home.json` is a legal display configuration in radians. It does not change URDF
zero transforms, limits or the simulator's initial state. The primary preview uses
this configuration; joint names and values are explicit and reproducible.

From a checkout or unpacked source at the fixed revision:

```bash
python scripts/import_ur5e.py /path/to/Universal_Robots_ROS2_Description
python scripts/smoke_urdf.py --model UniversalRobotsUR5e --json /tmp/ur5e-smoke.json
NODE_PATH=/tmp/humanoid-asset-validation/node_modules \
  node scripts/validate_glb.cjs UniversalRobotsUR5e --json /tmp/ur5e-glb.json
blender -b --factory-startup --python-exit-code 1 --python scripts/render_previews.py -- \
  UniversalRobotsUR5e --joint-positions UniversalRobotsUR5e/home.json \
  --output-dir /tmp/ur5e-previews
```

Import dependencies: Python, xacro, PyYAML, NumPy, SciPy, pycollada and Pillow, plus
the repository's GLB conversion and normal-refinement helpers. The
importer verifies every input against the pinned blob hashes before writing.
Loading and rendering require no source checkout, package URI resolver or network.

Validation evidence is in `validation.json` and `source/conversion.json`; these
cover loading and articulation rather than contact dynamics or physical control.
